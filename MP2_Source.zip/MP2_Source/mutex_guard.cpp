#include "mutex_guard.hpp"

MutexGuard::MutexGuard(Mutex &m) {
}

MutexGuard::~MutexGuard() {
}
