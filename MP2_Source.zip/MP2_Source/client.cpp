/* 
    File: simpleclient.cpp

    Author: R. Bettati
            Department of Computer Science
            Texas A&M University
    Date  : 2019/09/23

    Simple client main program for MP2 in CSCE 313
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include <cassert>
#include <string>
#include <iostream>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#include <errno.h>
#include <unistd.h>

#include "reqchannel.hpp"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */ 
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* LOCAL FUNCTIONS -- SUPPORT FUNCTIONS */
/*--------------------------------------------------------------------------*/

std::string int2string(int number) {
  std::stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   return ss.str();//return a string with the contents of the stream
}

std::string generate_data() {
  // Generate the data to be returned to the client.
  return int2string(rand() % 100);
}

std::string process_request(const std::string & _request) {

  if (_request.compare(0, 5, "hello") == 0) {
    return "hello to you, too";
  }
  else if (_request.compare(0, 4, "data") == 0) {
    return generate_data();
  }
  else {
    return "unknown request";
  }

}

/*--------------------------------------------------------------------------*/
/* MAIN FUNCTION */
/*--------------------------------------------------------------------------*/

int main(int argc, char * argv[]) {
  pid_t pid;
  if (pid = fork() == 0) {
    // child process
    system("./dataserver");
  }else {
    std::cout << "CLIENT STARTED:" << std::endl;

    std::cout << "Establishing control channel... " << std::flush;
    RequestChannel chan("control", RequestChannel::Side::CLIENT);
    std::cout << "done." << std::endl;

    /* -- Start sending a sequence of requests */
    timeval start1, end1, start2, end2, start3, end3, start4, end4;
 
    gettimeofday(&start1, nullptr);
    std::string reply1 = chan.send_request("hello");
    gettimeofday(&end1, nullptr);
    std::cout << "Reply to request 'hello' is '" << reply1 << "'" << std::endl;

    gettimeofday(&start2, nullptr);
    std::string reply2 = chan.send_request("data Joe Smith");
    gettimeofday(&end2, nullptr);
    std::cout << "Reply to request 'data Joe Smith' is '" << reply2 << "'" << std::endl;

    gettimeofday(&start3, nullptr);
    std::string reply3 = chan.send_request("data Jane Smith");
    gettimeofday(&end3, nullptr);
    std::cout << "Reply to request 'data Jane Smith' is '" << reply3 << "'" << std::endl;

    for(int i = 0; i < 100; i++) {
      std::string request_string("data TestPerson" + int2string(i));
      std::string reply_string = chan.send_request(request_string);
      // std::cout << "reply to request " << i << ":" << reply_string << std::endl;;
    }

    /* -- Start meassuring the local call */
    timeval Start1, End1, Start2, End2, Start3, End3;

    gettimeofday(&Start1, nullptr);
    std::string Reply1 = process_request("hello");
    gettimeofday(&End1, nullptr);

    gettimeofday(&Start2, nullptr);
    std::string Reply2 = process_request("data Joe Smith");
    gettimeofday(&End2, nullptr);

    gettimeofday(&Start3, nullptr);
    std::string Reply3 = process_request("data Jane Smith");
    gettimeofday(&End3, nullptr);
    /* -- End meassuring the local call */

    gettimeofday(&start4, nullptr);
    std::string reply4 = chan.send_request("quit");
    gettimeofday(&end4, nullptr);
    std::cout << "Reply to request 'quit' is '" << reply4 << std::endl;

    std::cout<<"Time spend on server to send hello is "<<end1.tv_sec-start1.tv_sec<<" secs and "<<end1.tv_usec-start1.tv_usec<<" musecs."<<std::endl;
    std::cout<<"Time spend on server to send data Joe Smith is "<<end2.tv_sec-start2.tv_sec<<" secs and "<<end2.tv_usec-start2.tv_usec<<" musecs."<<std::endl;
    std::cout<<"Time spend on server to send data Jane Smith is "<<end3.tv_sec-start3.tv_sec<<" secs and "<<end3.tv_usec-start3.tv_usec<<" musecs."<<std::endl;
    std::cout<<"Time spend on server to send quit is "<<end4.tv_sec-start4.tv_sec<<" secs and "<<end4.tv_usec-start4.tv_usec<<" musecs."<<std::endl;
    std::cout<<std::endl<<"Meassurements of local calls:"<<std::endl;
    std::cout<<"Time spend on server to send hello is "<<End1.tv_sec-Start1.tv_sec<<" secs and "<<End1.tv_usec-Start1.tv_usec<<" musecs."<<std::endl;
    std::cout<<"Time spend on server to send data Joe Smith is "<<End2.tv_sec-Start2.tv_sec<<" secs and "<<End2.tv_usec-Start2.tv_usec<<" musecs."<<std::endl;
    std::cout<<"Time spend on server to send data Jane Smith is "<<End3.tv_sec-Start3.tv_sec<<" secs and "<<End3.tv_usec-Start3.tv_usec<<" musecs."<<std::endl;

    usleep(1000000);
  }
}
