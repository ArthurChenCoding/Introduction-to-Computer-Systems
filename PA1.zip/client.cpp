/*
    Tanzir Ahmed
    Department of Computer Science & Engineering
    Texas A&M University
    Date  : 2/8/20
 */
#include "common.h"
#include "FIFOreqchannel.h"
#include <typeinfo>
using namespace std;


int main(int argc, char *argv[]){
	pid_t pid;
	int opt;
	int p = 1;
	double t = 0.0;
	int e = 1;
	bool creatNewChannel = false;
	bool MAX_MESSAGE_changed = false;
	int buffersize = MAX_MESSAGE;
	char buf [buffersize]; // 256

	string filename = "10.csv";
	while ((opt = getopt(argc, argv, "p:t:e:c:f:m:")) != -1) {
		switch (opt) {
			case 'p':
				p = atoi (optarg);
				break;
			case 't':
				t = atof (optarg);
				break;
			case 'e':
				e = atoi (optarg);
				break;
			case 'f':
				filename = optarg;
				break;
			case 'c':
				creatNewChannel = optarg;
				break;
			case 'm':
				MAX_MESSAGE_changed = true;
				buffersize = atoi(optarg);
				break;
			case '?':
    			std::cout<<"invalid command line argument"<<std::endl;
    			assert(false);
      		default :
        		std::cout<<"default"<<std::endl;
    			assert(false);
		}
	}
	if ((pid = fork()) == 0) {
    	// child process for server
		if(MAX_MESSAGE_changed){
			string commandline = ("./server -m "+to_string(buffersize));
			system(commandline.c_str());
		}else{
			system("./server");
		}
  	}else {
		std::cout << "CLIENT STARTED:" << std::endl;
		std::cout << "Establishing control channel... " << std::flush << endl;;
		FIFORequestChannel chan ("control", FIFORequestChannel::CLIENT_SIDE);
	
		fstream fout;
		cout<<"Note: if no -p argument has entered, default is 1." << endl;
		cout<<"Note: if no -f argument has entered, default is 10." << endl;
		cout<<"Note: if no -c argument has entered, default not creating new channels." << endl;
    	fout.open("received/"+to_string(p)+"x.csv", ios::out | ios::app); 
		cout<<"received/"+to_string(p)+"x.csv is opend"<<endl;
		cout<<"requesting 2000 data for client " << to_string(p) << " and the timer ahs started..." << endl;
		timeval start, end;
		gettimeofday(&start, nullptr); // start timer
		for (int i = 0; i < 1000 ;i++){
			datamsg* x = new datamsg(p, 0.004*i,1);
			chan.cwrite (x, sizeof (datamsg)); // question
			double* reply1 = new double;
			chan.cread (reply1, sizeof(double)); //answer
			datamsg* y = new datamsg(p, 0.004*i,2);
			chan.cwrite (y, sizeof (datamsg)); // question
			double* reply2 = new double;
			chan.cread (reply2, sizeof(double)); //answer
			double e1, e2;
			e1=*reply1;
			e2=*reply2;
			fout << (i*0.004) << ", " << e1 << ", " << e2 << ", "  << "\n"; 
			// cout << (i*0.004) << ", " << e1 << ", " << e2 << ", "  << "\n"; 
			// cout << "For person " << 1 <<", at time " << (i*0.004) << ", the value of ecg "<< i%2 <<" is " << *reply << endl;
			delete x;
			delete reply1;
			delete y;
			delete reply2;
		}
		fout.close(); 
		gettimeofday(&end, nullptr); // end timer
		if(end.tv_usec-start.tv_usec < 0){
			cout<<"timer ends and the time taken is "<<end.tv_sec-start.tv_sec-1<<" secs and "<<1-(end.tv_usec-start.tv_usec)<<" musecs."<<endl;
		}else{
			cout<<"timer ends and the time taken is "<<end.tv_sec-start.tv_sec<<" secs and "<<end.tv_usec-start.tv_usec<<" musecs."<<endl;
		}
		cout<<"Checking if received 2000 data points are correct..."<<endl;
		cout<<"The method I used is to open the received file again, read it line by line. For each line," <<
		"request the data with same timestamp from the server again to compare if e1 and e2 are the correct."<<endl;
		ifstream fin; 
		string line;
		string segment;
		vector<string> parts;
		fin.open("received/"+to_string(p)+"x.csv", ios::in); 
		bool filematched = true;
		for(int i = 0; i < 1000; i++){
            getline(fin,line);
			// cout<<line<<endl;
			parts = split(line,',');
			string time = parts[0];
			// cout<<"time: "<< time<<endl;
			int eIs;
			double eValue1;
			double eValue2;
			// cout<< "parts[1]: " << parts[1] << endl;
			eValue1 = stod(parts[1]);
			eValue2 = stod(parts[2]);
			datamsg* x = new datamsg(p, stod(time),1);
			chan.cwrite (x, sizeof (datamsg)); // question
			double* reply1 = new double;
			chan.cread (reply1, sizeof(double)); //answer
			datamsg* y = new datamsg(p, stod(time),2);
			chan.cwrite (y, sizeof (datamsg)); // question
			double* reply2 = new double;
			chan.cread (reply2, sizeof(double)); //answer
			if(eValue1 != *reply1 || eValue2 != *reply2){
				cout<<"value not matched! at time: " << time << "received is " << eValue1 << " and " << eValue2 << " actual is " << *reply1 << " & " << *reply2 <<endl;
				filematched = false;
				break;
			}
			delete x;
			delete reply1;
			delete y;
			delete reply2;
        }
		if(filematched){
			cout<<"entire file matched!"<<endl;
		}

		// get file length
		filemsg fm (0,0);
		char* buf2 = new char [sizeof (filemsg) + filename.size() + 1]; // creating a buffer to hold segment header and size of the file name itself
		memcpy(buf2, &fm, sizeof(filemsg));
		memcpy(buf2+sizeof (filemsg), filename.c_str(), filename.size() + 1);
		// cout<<"buf2 is "<<&buf2<<endl;
		chan.cwrite (buf2, sizeof(filemsg)+filename.size()+1);
		__int64_t reply;
		chan.cread (&reply, sizeof(__int64_t)); //answer
		// cout<<"The requested file length is "<< reply <<endl;
		delete buf2;

		// calculate number of delivery
		int num = reply/buffersize+1;
		int extra = (num)*buffersize-reply; // the size of extra part
		// cout <<"Number of transfer needed is " <<num << " and extra of transfer power in bytes is " << extra <<endl;
		int windowsize = buffersize;

		fstream fout2;
    	fout2.open("received/"+filename, ios::out | ios::app); 
		// cout<<"received/"+filename +" has opened"<<endl;
		cout<<endl<<"start to transfer entire file and start the timer." << endl;
		timeval start2, end2;
		gettimeofday(&start2, nullptr); // start timer
		for(int i = 0; i < num; i++){
			if(i == num-1){
				// cout<<"last iteration" << endl;
				filemsg fm2 (i*windowsize, windowsize-extra); 
				// cout<<"The offset this time is " << i*windowsize << " and length is " << windowsize-extra << endl;
				char buf3 [sizeof (filemsg) + filename.size() + 1];
				memcpy(buf3, &fm2, sizeof(filemsg));
				// memcpy(buf3+sizeof (filemsg), filename.c_str(), filename.size() + 1);
				strcpy(buf3 + sizeof (filemsg), filename.c_str());
				chan.cwrite (buf3, sizeof(buf3));
				char recvbuf[windowsize-extra];
				chan.cread(recvbuf, sizeof(recvbuf));
				fout2 << recvbuf;
				// cout<<"recvbuf is " <<recvbuf<<endl;
			}else{
				filemsg fm2 (i*windowsize, windowsize); 
				// cout<<"The offset this time is " << i*windowsize << " and length is " << windowsize << endl;
				char buf3 [sizeof (filemsg) + filename.size() + 1];
				memcpy(buf3, &fm2, sizeof(filemsg));
				// memcpy(buf3+sizeof (filemsg), filename.c_str(), filename.size() + 1);
				strcpy(buf3 + sizeof (filemsg), filename.c_str());
				chan.cwrite (buf3, sizeof(buf3));
				char recvbuf [255];
				chan.cread(recvbuf, sizeof(recvbuf));
				fout2 << recvbuf;
				// cout<</*"recvbuf is "<<recvbuf << endl <<*/ "the size of " << i+1 << "th transection is " << sizeof(recvbuf) <<endl;
				// delete buf3;
				// delete recvbuf;
			}
		}

		fout2.close();
		gettimeofday(&end2, nullptr); // end timer
		if(end2.tv_usec-start2.tv_usec < 0){
			cout<<"Transfer has completed and the time taken is "<<end2.tv_sec-start2.tv_sec-1<<" secs and "<<1-(end2.tv_usec-start2.tv_usec)<<" musecs."<<endl;
		}else{
			cout<<"Transfer has completed and the time taken is "<<end2.tv_sec-start2.tv_sec<<" secs and "<<end2.tv_usec-start2.tv_usec<<" musecs."<<endl;
		}
		// cout<<"checking if received file is the same..."<<endl;

		if(creatNewChannel){
			cout<<endl<<"Creating new channel"<<endl;
			MESSAGE_TYPE n = NEWCHANNEL_MSG;
			chan.cwrite (&n, sizeof (MESSAGE_TYPE));
			char reply[30];
			chan.cread (reply, sizeof(reply)); //answer
			// cout<<"reply is "<<reply<<endl;
			// FIFORequestChannel chan ("control", FIFORequestChannel::CLIENT_SIDE);
			FIFORequestChannel *data_channel = new FIFORequestChannel (reply, FIFORequestChannel::CLIENT_SIDE);
			datamsg* x = new datamsg(p, 0.04,1);
			data_channel->cwrite(x, sizeof (datamsg)); // question
			double* reply1 = new double;
			data_channel->cread (reply1, sizeof(double)); //answer
			cout<<"reply1 from server through new channel is "<<*reply1<<endl;
			datamsg* y = new datamsg(p, 0.08,2);
			data_channel->cwrite(y, sizeof (datamsg)); // question
			double* reply2 = new double;
			data_channel->cread (reply2, sizeof(double)); //answer
			cout<<"reply2 from server through new channel is "<<*reply2<<endl;
			delete x;
			delete reply1;
			delete y;
			delete reply2;
			// closing the channel   
			cout<<"senting quit_msg to data_channel channel"<<endl; 
			MESSAGE_TYPE m = QUIT_MSG;
			data_channel->cwrite (&m, sizeof (MESSAGE_TYPE));
		}
		
		// closing the channel   
		cout<<"senting quit_msg to control channel"<<endl; 
		MESSAGE_TYPE m = QUIT_MSG;
		chan.cwrite (&m, sizeof (MESSAGE_TYPE));
		usleep(3000000); // to ensure server is closed
	}
}
